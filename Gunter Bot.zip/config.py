settings = {
    'token': 'MTAwODExNjc3NDU5NzgyNDYwMw.GdIlcK.9VCZyYhj-L1j5MEqliSeBrWhbkqx2zmTzFFlmw',
    'version': '0.0.1',
    'prefix': '.'
}